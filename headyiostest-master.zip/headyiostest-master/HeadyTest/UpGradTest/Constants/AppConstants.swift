//
//  AppConstants.swift
//  UpGradTest
//
//  Created by Vivek Shinde on 03/10/19.
//  Copyright © 2019 Vivek Shinde. All rights reserved.
//

import Foundation

struct AppConstants {
    static  let imdbApiKey = "b3f499b62957665be727e11b35d53ed8"
}




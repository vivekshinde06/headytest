# upgradiostest

App Architecture : MVVM model

Third Party libraries 

1. KingFisher : For asynchronous image loading + image caching for reuse
2. Rechablity : For interner connection checking 

Design patterns used : Singleton, Delegation , NSNotificationCenter

Test cases written for for -> request + response : sucess/ failure, response time, response content type = application/json
